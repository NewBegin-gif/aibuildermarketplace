# Software Portability Test kits v1.0.0

17 category kits, two synthetic records each. Use only categories in release.json. Category kit.json, CSV, attachments and README bytes are unchanged from the 24 October 2026 release. Normative category instructions are in Dutch; the accompanying English specification defines outcomes and the protocol. No real recipients or customer data. Record both export and re-import stages.

The public archive excludes internal provenance paths, QA drafts and build tooling. SHA256SUMS lists exactly the archive files except itself. This is a packaging manifest; per-kit hashes and kit JSON hashes remain unchanged. Native-ID exports are private evidence and must not be added here.
