# Voorraad/productcatalogus — testkit 1.0.0

Deze kit bevat exact twee records, `AIBM-001` en `AIBM-002`. Alle personen en organisaties zijn fictief; `example.com` is alleen testdata. Er staan geen telefoonnummers of adressen in.

## Gebruik

1. Lees [het vaste protocol](../README.md) en controleer de SHA-256 in `kit.json` en `../SHA256SUMS`.
2. Gebruik een geïsoleerde, stille testscope. Geen verzending, uitnodiging, betaalactie, publicatie of workflow activeren. Alle e-mails zijn fictief; vervang ze niet stilzwijgend door echte adressen.
3. Objecttype: **product**. Koppel de velden volgens `kit.json.fields`. `record_date` betekent **zelf ingevoerde controledatum**; `amount` betekent **eenheidsprijs EUR**. Map `custom_code` naar het zelf aangemaakte veld **AIBM Custom Code**. Map `free_text` naar een apart bewerkbaar tekstveld.
4. CSV is UTF-8 zonder BOM, komma-gescheiden, met dubbele aanhalingstekens en geciteerde regelovergangen. `tags` heeft twee waarden gescheiden door `|`. Converteer in een werkkopie als de tool andere headers, datatypes of delimiters eist; wijzig de kit nooit.
5. Upload beide bestanden uit de kolom `attachment` afzonderlijk en koppel ze aan het juiste record. Een CSV-bestandsnaam uploadt de bytes niet. Bijlagebeleid: `optional` (core = primaire invoer, optional = alleen indien ondersteund).
6. Controleer de opgeslagen invoer, leg interne IDs vast, exporteer alle velden, bewaar het echte exportbestand en vergelijk met de grondwaarheid. Voer de tien vaste controles uit; leg per record het bewijs vast.
7. Herimport: gebruik de eigen IDs uit de export. Wijzig **uitsluitend `free_text` van AIBM-002**, volgens de exacte `updated_value` in `kit.json.reimport`. Alle overige cellen blijven gelijk aan de export. Gebruik update existing; exporteer opnieuw en controleer beide IDs, twee records, geen dubbelen en ongewijzigd AIBM-001. Zonder passend updatepad: `not_offered`; geen herstel claimen.
8. Vul [het meetlogvoorstel](../meetlog-schema.md) in een nieuw testverslag in. Deze release bevat geen gemeten tooluitkomsten.

## Toegestane weigeringen

Datum, custom field, tags en bijlage mogen ontbreken op producten. SKU is een zakelijke sleutel, geen automatisch bewijs dat het interne ID behouden blijft.

Dit is geen fout zolang de capability werkelijk niet wordt aangeboden en het bewijs wordt vastgelegd als `not_offered`. Was een waarde wel opgeslagen maar ontbreekt die in een volledig onderzocht exportbestand, dan is het `lost`. Is het alleen niet geprobeerd of is de beperking onbekend, dan is het `not_tested`. Een abonnementblokkade geldt uitsluitend voor het vastgelegde plan, niet voor het hele product. Ondersteunde velden mogen niet ongemerkt naar één notitie worden samengevoegd.

Een ontbrekend of niet aangeboden `free_text`-veld verhindert het vaste herimportscenario; kies geen ander veld zonder nieuwe kitversie. Export en herimport krijgen elk een eigen uitkomst. Native metadata ontbreekt mogelijk terwijl dezelfde tekst in een PDF/PNG zichtbaar is: scoor alleen het gemapte veld.

## Reikwijdte

Catalogusvelden en aantallen; geen magazijnmutaties, verkooporders of productieruns.

Bij ongewijzigde bestandsopslag eisen we gelijke SHA-256. Bij toegestane beeldtransformatie of gegenereerde uitvoer leg je het nieuwe artefact vóór de export als referentie vast; vergelijk de latere download met die referentie. Een byteverschil door compressie wordt `changed` met uitleg, geen automatisch verlies van inhoud. Nieuwe handtekeningen zijn buiten scope.

Aanvullende categorievelden hebben geen elfde check: noteer hun vergelijking als veldbewijs bij `records_returned` of `reimport_update_only`, en rapporteer beperkingen afzonderlijk. Claims over zo'n extra veld worden niet afgeleid uit een geslaagde recordtelling.
